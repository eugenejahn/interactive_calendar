# interactive_calendar
The interactive calendar is a organization based calendar that allows the user(you) to add activites that you have done and it can color code those activities. It can also be used as a regular calendar to put dates in the future.

 
to use this program you need to:
1. Create a Maven file of a sort, NetBeans is the application we used.
2. copy the javaaplication1 package to the Source package
3. And the following text into the pom.xml file below &lt;properties> but inside &lt;project>

&lt;dependencies>
<br>
&lt;dependency>
<br>
            &lt;groupId>com.google.code.gson &lt;/groupId>
<br> 
            &lt;artifactId>gson &lt;/artifactId>
            <br>
            &lt;version>2.3 &lt;/version>
            <br>
&lt;/dependency>
<br>
&lt;/dependencies>



4. Run the application
5. Select javaaplication1.Main as the main file





![alt text](https://github.com/rooseveltcs/interactive_calendar/blob/master/1.PNG)
![alt text](https://github.com/rooseveltcs/interactive_calendar/blob/master/2.PNG)
