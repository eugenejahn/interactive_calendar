/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author ros_eyjahn
 */
public class DateData {
    private String date;
		private String[] data;
 
		public String[] getData() {
			return data;
		}
 
		public void setData(String[] data) {
			this.data = data;
		}
 
		public String getDate() {
			return date;
		}
 
		public void setDate(String date) {
			this.date = date;
		}
}
